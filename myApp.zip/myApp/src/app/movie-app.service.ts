import { Injectable } from '@angular/core';
import { MovieInfo } from './models/movie-info.model';
import { GenreType } from './models/enums';

@Injectable({
  providedIn: 'root'
})
export class MovieAppService {
  private baseUrl = 'http://localhost:8090/api/';
  listOfMovies: Array<MovieInfo> = [];

  constructor() { }

  addNewMovie(newMovie: MovieInfo){
    this.listOfMovies.push(newMovie);
  }

  searchMovie(genre: GenreType){
    return this.listOfMovies.filter(v => v.genre == genre);
  }
}
