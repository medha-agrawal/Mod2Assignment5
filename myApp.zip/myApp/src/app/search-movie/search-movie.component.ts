import { Component, OnInit } from '@angular/core';
import { FormControl } from '@angular/forms';
import { MovieAppService } from '../movie-app.service';
import { MovieInfo } from '../models/movie-info.model';

@Component({
  selector: 'app-search-movie',
  templateUrl: './search-movie.component.html',
  styleUrls: ['./search-movie.component.css']
})
export class SearchMovieComponent implements OnInit {

  genre: FormControl;
  movieList: Array<MovieInfo> = [];
  constructor(private movieAppService: MovieAppService) { }

  ngOnInit(): void {
    this.genre = new FormControl(null);
  }

  searchMovie(){
  this.movieList = this.movieAppService.searchMovie(+this.genre.value);
}
}
