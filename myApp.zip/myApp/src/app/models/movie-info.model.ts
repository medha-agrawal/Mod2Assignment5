import { GenreType } from './enums';

export class MovieInfo {
    id?: number;
    name: string;
    rating: number;
    genre: GenreType;
    
    constructor(args: any){
        this.name = args.name;
        this.rating = +args.rating;
        this.genre = +args.genre;
    }
}