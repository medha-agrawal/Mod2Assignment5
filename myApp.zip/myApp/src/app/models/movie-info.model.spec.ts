import { MovieInfo } from './movie-info.model';

describe('MovieInfo.Model', () => {
  it('should create an instance', () => {
    expect(new MovieInfo({})).toBeTruthy();
  });
});
